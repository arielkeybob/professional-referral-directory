# Registro de Mudanças (Changelog) do ProfessionalDirectory

Este arquivo documenta todas as alterações significativas feitas em cada versão do plugin ProfessionalDirectory.

## [Versão Atual]

- Data de lançamento: [Data de Lançamento]
- Resumo das principais mudanças nesta versão.

## [Versão Anterior]

- Data de lançamento: [Data de Lançamento]
- Lista de mudanças realizadas nesta versão.

## Versões Anteriores

### [Versão X.Y.Z]

- Data de lançamento: [Data de Lançamento]
- Mudanças detalhadas.

### [Versão X.Y.Z-1]

- Data de lançamento: [Data de Lançamento]
- Mudanças detalhadas.

---

Este changelog segue o [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) e adere ao [Versionamento Semântico](https://semver.org/).

Desenvolvido por Ariel SOuza
